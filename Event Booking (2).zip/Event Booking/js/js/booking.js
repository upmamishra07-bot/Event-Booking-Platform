const prices = {

    "Sunset Music Festival": 799,

    "Future Tech Summit": 999,

    "Creative Design Workshop": 599

};


const eventSelect =
    document.getElementById("eventSelect");

const tickets =
    document.getElementById("tickets");

const totalPrice =
    document.getElementById("totalPrice");


function calculateTotal() {

    const event =
        eventSelect.value;

    const quantity =
        Number(tickets.value);

    const price =
        prices[event];

    totalPrice.textContent =
        price * quantity;

}


eventSelect.addEventListener(
    "change",
    calculateTotal
);

tickets.addEventListener(
    "input",
    calculateTotal
);


document
.getElementById("bookingForm")
.addEventListener("submit", function(e) {

    e.preventDefault();

    const name =
        document.getElementById("name").value.trim();

    const email =
        document.getElementById("email").value.trim();

    const phone =
        document.getElementById("phone").value.trim();

    const event =
        eventSelect.value;

    const quantity =
        Number(tickets.value);

    let valid = true;


    document.getElementById("nameError").textContent = "";
    document.getElementById("emailError").textContent = "";
    document.getElementById("phoneError").textContent = "";


    if (name.length < 3) {

        document.getElementById("nameError")
            .textContent =
            "Please enter a valid name.";

        valid = false;

    }


    if (!email.includes("@")) {

        document.getElementById("emailError")
            .textContent =
            "Please enter a valid email.";

        valid = false;

    }


    if (!/^[0-9]{10}$/.test(phone)) {

        document.getElementById("phoneError")
            .textContent =
            "Please enter a valid 10 digit phone number.";

        valid = false;

    }


    if (quantity < 1 || quantity > 10) {

        valid = false;

        alert("You can book 1 to 10 tickets.");

    }


    if (!valid) {
        return;
    }


    const booking = {

        id:
            "EVT" +
            Math.floor(
                100000 +
                Math.random() * 900000
            ),

        name: name,

        email: email,

        phone: phone,

        event: event,

        tickets: quantity,

        total:
            prices[event] * quantity

    };


    localStorage.setItem(
        "booking",
        JSON.stringify(booking)
    );


    window.location.href =
        "confirmation.html";

});

