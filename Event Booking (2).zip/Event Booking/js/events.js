const events = [

    {
        id: 1,
        name: "Sunset Music Festival",
        category: "Music",
        date: "20 September 2026",
        time: "6:00 PM",
        location: "Bangalore",
        price: 799,
        image: "images/music.jpg",
        description: "Live music, entertainment and amazing performances."
    },

    {
        id: 2,
        name: "Future Tech Summit",
        category: "Technology",
        date: "25 September 2026",
        time: "10:00 AM",
        location: "Bangalore",
        price: 999,
        image: "images/tech.jpg",
        description: "Explore AI, cloud computing and future technologies."
    },

    {
        id: 3,
        name: "Creative Design Workshop",
        category: "Workshop",
        date: "02 October 2026",
        time: "11:00 AM",
        location: "Mumbai",
        price: 599,
        image: "images/workshop.jpg",
        description: "Learn modern creative design techniques."
    },

    {
        id: 4,
        name: "Business Leadership Summit",
        category: "Business",
        date: "08 October 2026",
        time: "10:00 AM",
        location: "Delhi",
        price: 1299,
        image: "images/business.jpg",
        description: "Learn leadership and business strategies."
    },

    {
        id: 5,
        name: "Color Splash Festival",
        category: "Festival",
        date: "15 October 2026",
        time: "4:00 PM",
        location: "Pune",
        price: 499,
        image: "images/festival.jpg",
        description: "Celebrate music, colors, food and culture."
    },

    {
        id: 6,
        name: "Champions Sports Meet",
        category: "Sports",
        date: "22 October 2026",
        time: "9:00 AM",
        location: "Hyderabad",
        price: 399,
        image: "images/sports.jpg",
        description: "An exciting day full of sports and competitions."
    }

];

const container =
    document.getElementById("eventsContainer");

const searchInput =
    document.getElementById("searchInput");

const categoryFilter =
    document.getElementById("categoryFilter");


function displayEvents(data) {

    container.innerHTML = "";

    if (data.length === 0) {

        container.innerHTML =
            `<div class="no-events">
                <h2>No events found</h2>
                <p>Try another search or category.</p>
            </div>`;

        return;
    }

    data.forEach(event => {

        const card = document.createElement("div");

        card.className = "event-card";

        card.innerHTML = `

            <img src="${event.image}"
                 alt="${event.name}">

            <div class="event-content">

                <span class="event-category">
                    ${event.category}
                </span>

                <h3>${event.name}</h3>

                <p>📅 ${event.date}</p>

                <p>⏰ ${event.time}</p>

                <p>📍 ${event.location}</p>

                <div class="event-bottom">

                    <strong>₹${event.price}</strong>

                    <a href="event-details.html?id=${event.id}">
                        View Details
                    </a>

                </div>

            </div>
        `;

        container.appendChild(card);

    });

}


function filterEvents() {

    const search =
        searchInput.value.toLowerCase();

    const category =
        categoryFilter.value;

    const filtered =
        events.filter(event => {

            const matchesSearch =
                event.name
                .toLowerCase()
                .includes(search);

            const matchesCategory =
                category === "all" ||
                event.category === category;

            return matchesSearch &&
                   matchesCategory;

        });

    displayEvents(filtered);

}


searchInput.addEventListener(
    "input",
    filterEvents
);

categoryFilter.addEventListener(
    "change",
    filterEvents
);

displayEvents(events);

